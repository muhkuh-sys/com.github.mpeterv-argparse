Argparse tutorial
=================

Contents:

.. toctree::

   parsers
   arguments
   options
   mutexes
   commands
   defaults
   callbacks
   misc

This is a tutorial for `argparse <https://github.com/mpeterv/argparse>`_, a feature-rich command line parser for Lua.
